#ifndef PRIMES_9183746069462
#define PRIMES_9183746069462
int prime(int x);
int nextprime(int x);
int primescount(int l, int r);
#endif
